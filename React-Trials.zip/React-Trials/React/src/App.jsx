import React, { useState } from 'react';
import image from "./assets/mp.jpg";

const App = () => {
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [email, setEmail] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(firstname, lastname, email);
  
  };

  return (
    <div>
      <div className="container">
        <h1>Welcome to my Website.</h1>
        <h2>
          React Jsx for beginners 
        </h2>
        <img src={image} alt="mp" />
        <form onSubmit={handleSubmit}>
          <div className="form-container">
            <label>
              First Name:
              <input 
                type="text" 
                className='form' 
                placeholder='Firstname' 
                required 
                value={firstname} 
                onChange={(event)=> setFirstname(event.target.value)} 
              />
            </label>
            <label>
              Last Name:
              <input 
                type="text" 
                className='form' 
                placeholder='Lastname' 
                required 
                value={lastname} 
                onChange={(event)=> setLastname(event.target.value)}
              />
            </label>
            <label>
              Email:
              <input 
                type='email' 
                className='form' 
                placeholder='Email' 
                required 
                value={email} 
                onChange={(event)=> setEmail(event.target.value)}
              />
            </label>
            <button type='submit'>Submit</button>
          </div>
        </form>
        <h2 className='headline header'>
          {firstname} {lastname}
        </h2>
      </div>
    </div>
  );
};
